@extends('ntsm.layout')
@section('content')
<div class="container mb-5">
    <div class="card" style="width: 100%;">
        <div class="card-body">
          <h5 class="card-title">Product Is: {{ $product->name}}</h5>
          <a href="{{ route('products.index') }}"><span><-back</span></a>
        </div>
      </div>
</div>
<div class="container">
    <form action="{{ route('products.update', $product->id) }}" method="POST">
        @csrf
        @method('Put')
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Name</label>
            <input type="text" name="name" value="{{ $product->name }}" class="form-control" id="exampleFormControlInput1" placeholder="Product Name">
        </div>
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Price</label>
            <input type="text" name="price" value="{{ $product->price }}" class="form-control" id="exampleFormControlInput1" placeholder="Product Price">
          </div>
        <div class="mb-3">
            <label for="exampleFormControlTextarea1" class="form-label">Details</label>
            <textarea name="detail" value="" class="form-control" id="exampleFormControlTextarea1" rows="3">
                {{ $product->detail }}
            </textarea>
        </div>
        <div class="mb-3">
           <button style="width: 10% " type="submit" class="btn btn-success">Edit</button>
        </div>
    </form>
</div>

@endsection
