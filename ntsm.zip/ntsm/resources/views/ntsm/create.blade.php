@extends('ntsm.layout')
@section('content')
<div class="container mb-5">
    <div class="card" style="width: 100%;">
        <div class="card-body">
          <h5 class="card-title">New Product</h5>
          <a href="{{ route('products.index') }}"><span><-back</span></a>
        </div>
      </div>
</div>
<div class="container">
    <form action="{{ route('products.store') }}" method="POST">
        @csrf
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Name</label>
            <input type="text" name="name" class="form-control" id="exampleFormControlInput1" placeholder="Product Name">
        </div>
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Price</label>
            <input type="text" name="price" class="form-control" id="exampleFormControlInput1" placeholder="Product Price">
          </div>
        <div class="mb-3">
            <label for="exampleFormControlTextarea1" class="form-label">Details</label>
            <textarea name="detail" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
        </div>
        <div class="mb-3">
           <button style="width: 10% " type="submit" class="btn btn-success">Add</button>
        </div>
    </form>
</div>

@endsection
