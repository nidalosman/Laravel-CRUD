@extends('ntsm.layout')
@section('content')
<div class="container mb-5">
    <div class="card" style="width: 100%;">
        <div class="card-body">
          <h5 class="card-title">Edit Product</h5>
          <a href="{{ route('products.index') }}"><span><-back</span></a>
        </div>
      </div>
</div>
<div class="container">
    <form action="{{ route('products.store') }}" method="POST">
        @csrf
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label" style="font-weight: 500; font-size:30px; color:rgb(35, 35, 35); ">Product Name Is:
                <span>{{ $product->name }}</span>
            </label>
        </div>
        <hr>
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label" style="font-weight: 500; font-size:30px; color:rgb(35, 35, 35); ">Price Is:{{ $product->price }}</label>
        </div>
        <hr>
        <div class="mb-3">
            <label for="exampleFormControlTextarea1" class="form-label" style="font-weight: 500; font-size:30px; color:rgb(35, 35, 35); ">Description: {{ $product->detail }}</label>
        </div>
    </form>
</div>

@endsection

