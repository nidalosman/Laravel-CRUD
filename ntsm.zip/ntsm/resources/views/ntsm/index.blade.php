@extends('ntsm.layout')
@section('content')
<div class="container mb-3">
    <div class="card" style="width: 100%;">
        <div class="card-body">
          <h5 class="card-title">All Product</h5>
          <p class="card-text">This Page To Show All Product & Add New.</p>
          <a href="{{ route('products.create') }}">
            <button type="button" class="btn btn-success">Add New</button>
          </a>
        </div>
      </div>
</div>
<div class="container">
    @if ($message = Session::get('Success'))
    <div class="alert alert-danger" role="alert">
        {{ $message }}
    </div>
    @endif
<div class="container">
    <table class="table table-dark table-striped">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Price</th>
            <th scope="col">Actions</th>
          </tr>
        </thead>
        <tbody>
            @php
                $i = 1;
            @endphp
            @foreach ($product as $item)
                <tr>
                    <th scope="row">{{$i++}}</th>
                    <td>{{ $item->name }}</td>
                    <td>{{ $item->price }}</td>
                    <td>
                        <div class="container">
                            <div class="row">
                            <div class="col">
                                <a href="{{route('products.edit', $item->id)}}"><button type="button" style="width: 100px;" class="btn btn-primary">Edit</button></a>
                            </div>
                            <div class="col">
                               <a href="{{route('products.show', $item->id)}}"> <button type="button" style="width: 100px;" class="btn btn-warning">Show</button> </a>
                            </div>
                            <div class="col">
                                <form action="{{ route('products.destroy' , $item->id) }}" method="POST">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" style="width: 100px;" class="btn btn-danger">Delete</button>
                                </form>
                            </div>
                            </div>
                        </div>
                    </td>
                </tr>
            @endforeach
        </tbody>
      </table>
      {{ $product->links()}}
</div>
@endsection
