<?php $__env->startSection('content'); ?>
<div class="container mb-3">
    <div class="card" style="width: 100%;">
        <div class="card-body">
          <h5 class="card-title">All Product</h5>
          <p class="card-text">This Page To Show All Product & Add New.</p>
          <a href="<?php echo e(route('products.create')); ?>">
            <button type="button" class="btn btn-success">Add New</button>
          </a>
        </div>
      </div>
</div>
<div class="container">
    <?php if($message = Session::get('Success')): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo e($message); ?>

    </div>
    <?php endif; ?>
<div class="container">
    <table class="table table-dark table-striped">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Price</th>
            <th scope="col">Actions</th>
          </tr>
        </thead>
        <tbody>
            <?php
                $i = 1;
            ?>
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($i++); ?></th>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->price); ?></td>
                    <td>
                        <div class="container">
                            <div class="row">
                            <div class="col">
                                <a href="<?php echo e(route('products.edit', $item->id)); ?>"><button type="button" style="width: 100px;" class="btn btn-primary">Edit</button></a>
                            </div>
                            <div class="col">
                               <a href="<?php echo e(route('products.show', $item->id)); ?>"> <button type="button" style="width: 100px;" class="btn btn-warning">Show</button> </a>
                            </div>
                            <div class="col">
                                <form action="<?php echo e(route('products.destroy' , $item->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" style="width: 100px;" class="btn btn-danger">Delete</button>
                                </form>
                            </div>
                            </div>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <?php echo e($product->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('ntsm.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\ntsm\resources\views/ntsm/index.blade.php ENDPATH**/ ?>