<?php $__env->startSection('content'); ?>
<div class="container mb-5">
    <div class="card" style="width: 100%;">
        <div class="card-body">
          <h5 class="card-title">Edit Product</h5>
          <a href="<?php echo e(route('products.index')); ?>"><span><-back</span></a>
        </div>
      </div>
</div>
<div class="container">
    <form action="<?php echo e(route('products.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label" style="font-weight: 500; font-size:30px; color:rgb(35, 35, 35); ">Product Name Is:
                <span><?php echo e($product->name); ?></span>
            </label>
        </div>
        <hr>
        <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label" style="font-weight: 500; font-size:30px; color:rgb(35, 35, 35); ">Price Is:<?php echo e($product->price); ?></label>
        </div>
        <hr>
        <div class="mb-3">
            <label for="exampleFormControlTextarea1" class="form-label" style="font-weight: 500; font-size:30px; color:rgb(35, 35, 35); ">Description: <?php echo e($product->detail); ?></label>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('ntsm.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Laravel\ntsm\resources\views/ntsm/show.blade.php ENDPATH**/ ?>